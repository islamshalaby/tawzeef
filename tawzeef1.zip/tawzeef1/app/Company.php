<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    protected $fillable = ['name_en', 'name_ar', 'image', 'email', 'website', 'category_id', 'country_id', 'description_en', 'description_ar', 'phone', 'address', 'facebook', 'twitter', 'linkedin', 'youtube'];
}
